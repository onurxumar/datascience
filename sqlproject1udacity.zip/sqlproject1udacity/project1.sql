##project SQL investigate a relational database

###questionset1

/* Query 1 - query used for first list of each movies rented out*/
##question1

SELECT f.title, c.name category, COUNT(*)
FROM category c
JOIN film_category fc
ON c.category_id = fc.category_id
JOIN film f
ON fc.film_id = f.film_id
JOIN inventory i
ON i.film_id = f.film_id
JOIN rental r
ON i.inventory_id = r.inventory_id
WHERE c.name IN ('Animation', 'Children', 'Classics', 'Comedy', 'Family', 'Music')
GROUP BY 1, 2
ORDER BY 2, 1

/* Query 2 - query used for first insight in the powerpoint*/
##question2

WITH t1 AS
(
           SELECT     f.film_id     AS film_id_1,
                      f.title       AS film_title,
                      c.NAME        AS category_name,
		      f.rental_duration,
		      NTILE(4) OVER (ORDER BY rental_duration) AS rental_standard_quartile
           FROM       film          AS f
           INNER JOIN film_category AS fc
           ON         f.film_id = fc.film_id
           INNER JOIN category AS c
           ON         fc.category_id = c.category_id
           WHERE      c.NAME IN ('Animation',
                                 'Children',
                                 'Classics',
                                 'Comedy',
                                 'Family',
                                 'Music')), t2 AS
(
                SELECT DISTINCT(i.film_id)                                       AS film_id_2,
                                Count(r.rental_id) OVER (partition BY i.film_id) AS rental_count
                FROM            inventory                                        AS i
                INNER JOIN      rental                                           AS r
                ON              i.inventory_id = r.inventory_id
                ORDER BY        film_id_2)

SELECT		t1.film_title,
    		t1.category_name,
    		t1.rental_duration,
    		t1.rental_standard_quartile,
    		t2.rental_count
FROM		t1
INNER JOIN	t2
ON		t1.film_id_1 = t2.film_id_2
ORDER BY	t1.rental_standard_quartile,
    		t2.rental_count DESC;


/* Query 3 - query used for second insight in the powerpoint*/
##question3

SELECT category, standard_quartile,
COUNT(*)
FROM
    (SELECT c.name category, f.rental_duration,
     NTILE(4) OVER (ORDER BY f.rental_duration) AS standard_quartile
     FROM category c
     JOIN film_category fc
     ON c.category_id = fc.category_id
     JOIN film f
     ON fc.film_id = f.film_id
     WHERE c.name IN ('Animation', 'Children', 'Classics', 'Comedy', 'Family', 'Music')) t1
GROUP BY category, standard_quartile
ORDER BY category, standard_quartile


###questionset2

/* Query 4 - query used for third insight in the powerpoint*/

##question1

SELECT DATE_PART('month',r.rental_date) AS rental_month,
       DATE_PART('year',r.rental_date) AS rental_year,
       sto.store_id,
       COUNT(*) AS rental_count
       FROM rental r
       JOIN payment p
       ON r.rental_id = p.rental_id
       JOIN staff sta
       ON p.staff_id = sta.staff_id
       JOIN store sto
       ON sta.store_id = sto.store_id
       GROUP BY rental_month, rental_year, sto.store_id
       ORDER BY rental_count DESC;


/* Query 5 - query used for fourth insight in the powerpoint*/
##question2

WITH top10 AS (SELECT c.customer_id, SUM(p.amount) AS total_payments
FROM customer c
JOIN payment p
ON p.customer_id = c.customer_id
GROUP BY c.customer_id
ORDER BY total_payments DESC
LIMIT 10)

SELECT DATE_TRUNC('month', payment_date) AS pay_mon, (first_name || ' ' || last_name) AS full_name, COUNT(p.amount) AS pay_countpermon, SUM(p.amount) AS pay_amount
FROM top10
JOIN customer c
ON top10.customer_id = c.customer_id
JOIN payment p
ON p.customer_id = c.customer_id
WHERE payment_date >= '2007-01-01' AND payment_date < '2008-01-01'
GROUP BY 1, 2
ORDER BY 2, 1


/* Query 6 - query used for difference accross customer payments*/
##question3

WITH top10 AS (SELECT c.customer_id, SUM(p.amount) AS total_payments
FROM customer c
JOIN payment p
ON p.customer_id = c.customer_id
GROUP BY c.customer_id
ORDER BY total_payments DESC
LIMIT 10),

t2 AS (SELECT DATE_TRUNC('month', payment_date) AS pay_mon, (first_name || ' ' || last_name) AS full_name,
SUM(p.amount) AS pay_amount
FROM top10
JOIN customer c
ON top10.customer_id = c.customer_id
JOIN payment p
ON p.customer_id = c.customer_id
WHERE payment_date >= '2007-01-01' AND payment_date < '2008-01-01'
GROUP BY 1, 2)

SELECT *,
LAG(t2.pay_amount) OVER (PARTITION BY full_name ORDER BY t2.pay_amount) AS lag,
(pay_amount - COALESCE(LAG(t2.pay_amount) OVER (PARTITION BY full_name ORDER BY t2.pay_mon), 0)) AS diff
FROM t2
ORDER BY diff DESC
